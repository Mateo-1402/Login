﻿import React, { useState } from "react";
import { fetchUser } from "../services/api";
import "../styles/spinner.css";
import "../styles/login.css";

// Componente de formulario de login
function LoginForm({ setUser }) {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [attempts, setAttempts] = useState(0);
    const [locked, setLocked] = useState(false);

    // Función que se ejecuta al enviar el formulario
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!username || !password) {
            setError("⚠️ Todos los campos son obligatorios.");
            return;
        }

        if (locked) {
            setError("🚫 Cuenta bloqueada por múltiples intentos fallidos.");
            return;
        }

        setLoading(true);
        setError("");

        const response = await fetchUser(username, password);

        setLoading(false);

        if (response.success) {
            setUser(response.user);
        } else {
            setAttempts((prev) => prev + 1);
            if (attempts + 1 >= 3) {
                setLocked(true);
                setError("🔒 Cuenta bloqueada tras 3 intentos fallidos.");
            } else {
                setError("❌ Usuario o contraseña incorrectos.");
            }
        }
    };

    // Vista del componente
    return (
        <div className="container">
            <h2>🔐 Iniciar Sesión</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Usuario"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                <input
                    type="password"
                    placeholder="Contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <button type="submit" disabled={loading}>Entrar</button>
            </form>

            {loading && <div className="spinner"></div>}
            {error && <p style={{ color: "red" }}>{error}</p>}
        </div>
    );
}

export default LoginForm;
