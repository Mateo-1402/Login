﻿import React from "react";
import "../styles/login.css";

function UserProfile({ user }) {
    return (
        <div className="container">
            <h2>👋 Bienvenido, {user.name}</h2>
            <p><strong>Usuario:</strong> {user.username}</p>
            <p><strong>Rol:</strong> {user.role}</p>

            {user.role === "admin" ? (
                <p style={{ color: "#2e86de" }}>🛠️ Tienes acceso completo como administrador.</p>
            ) : (
                <p style={{ color: "#27ae60" }}>👤 Acceso limitado como usuario regular.</p>
            )}
        </div>
    );
}

export default UserProfile;
