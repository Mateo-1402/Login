// Simulaci�n de una API que valida usuario y contrase�a
export async function fetchUser(username, password) {
  const fakeUsers = [
    { username: "admin", password: "1234", name: "Admin Juan", role: "admin" },
    { username: "user", password: "abcd", name: "User Mar�a", role: "user" },
  ];

  // Simula un retraso de red
  await new Promise(resolve => setTimeout(resolve, 1500));

  const found = fakeUsers.find(
    user => user.username === username && user.password === password
  );

  if (found) {
    return { success: true, user: found };
  } else {
    return { success: false };
  }
}
