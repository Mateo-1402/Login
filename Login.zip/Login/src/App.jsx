import React, { useState } from "react";
import LoginForm from "./components/LoginForm";
import UserProfile from "./components/UserProfile";

function App() {
    const [user, setUser] = useState(null);

    return (
        <div>
            {user ? (
                <UserProfile user={user} />
            ) : (
                <LoginForm setUser={setUser} />
            )}
        </div>
    );
}

export default App;
